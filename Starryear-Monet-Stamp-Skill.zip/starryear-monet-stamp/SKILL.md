---
name: starryear-monet-stamp
description: "Transform one user-supplied travel, landscape, architecture, garden, street, or quiet documentary photograph into a vertical 2:3 Starryear-Monet-Stamp archive artwork with photographic evidence above, a source-derived symbolic imprint in the middle, and a reconstructed luminous Monet-memory panel below. Use when the user requests 星年莫奈印章, Starryear-Monet-Stamp, EVIDENCE → IMPRINT → MONET MEMORY, or a travel photograph reconstructed as an archival postal artwork. Do not use for generic Monet filters, ordinary vintage posters, or invented destination art."
---

# Starryear-Monet-Stamp

Follow the complete canonical instructions in [references/Starryear-Monet-Stamp-完整口令.txt](references/Starryear-Monet-Stamp-完整口令.txt) exactly for every task that invokes this skill.

Treat the uploaded photograph as the primary and sole visual evidence. Respect a user-provided location; otherwise verify only what the photograph supports, and switch to a truthful scene identity when geography remains uncertain. The bottom section is English-only.

Preserve Starryear authorship when packaging, sharing, or describing the method.
